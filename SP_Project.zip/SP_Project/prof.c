#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "school.h"
// #include "prof.h"

/*
교직원 파일 사용,
교직원 등록 (이름, 전화번호, 주소, 주민번호, 사번(생성),
소속학과/부서, 계약기간, 정보 포함 및 추가 정보 등),
교직원 정보 검색(이름/전화번호/생년월일) 및
수정(전화번호, 주소, 소속학과/부서, 계약기간 포함 및 추가 정보 등)
*/

int prof(char* fileName) {

}
