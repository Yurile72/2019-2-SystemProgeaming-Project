#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "school.h"
// #include "assert.h"

/*
자산 파일 사용, 자산 등록(품명, 자산번호, 관리 부서, 관리담당, 
위치, 취득일, 취득가격 포함 및 추가 정보 등), 
자산 검색(품명, 자산번호, 관리 부서, 위치, 취득일) 및 
수정 (관리부서, 관리담당, 위치 포함 추가정보)

*/

int assert(char* fileName) {

}
