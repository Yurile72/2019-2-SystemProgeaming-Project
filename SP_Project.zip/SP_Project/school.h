int student(char* fileName);
int prof(char* fileName);
int assert(char* fileName);